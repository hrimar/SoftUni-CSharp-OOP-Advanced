﻿using System;

namespace P01.Database
{
    class Program
    {
        static void Main()
        {
          
        }
    }

}
