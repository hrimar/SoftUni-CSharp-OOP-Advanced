﻿using System;

namespace P09.DateTimeProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //DateTime date = new DateTime(2008, 02, 28);
            
            //Console.WriteLine(date.AddDays(1));
        }
    }
}
