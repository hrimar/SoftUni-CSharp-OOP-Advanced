﻿using System;

namespace ExtendedDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
