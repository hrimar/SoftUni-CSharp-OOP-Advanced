﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07.HackTests
{
    public  interface IMathFloor
    {
         double Floor(double d);
        
       decimal Floor(decimal d);
    }
}
