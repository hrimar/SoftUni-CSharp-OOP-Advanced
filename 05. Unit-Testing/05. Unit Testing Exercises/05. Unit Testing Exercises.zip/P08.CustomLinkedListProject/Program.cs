﻿using System;

namespace P08.CustomLinkedListProject
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
