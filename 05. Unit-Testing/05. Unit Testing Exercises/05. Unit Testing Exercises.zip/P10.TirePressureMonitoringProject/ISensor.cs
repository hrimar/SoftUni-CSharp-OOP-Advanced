﻿namespace P10.TirePressureMonitoringProject
{
    public interface ISensor
    {
        double PopNextPressurePsiValue();
    }
}