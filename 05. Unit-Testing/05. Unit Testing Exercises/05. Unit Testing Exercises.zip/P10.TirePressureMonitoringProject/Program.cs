﻿using System;

namespace P10.TirePressureMonitoringProject
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
