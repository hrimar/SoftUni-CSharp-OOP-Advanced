﻿using System;

namespace P06.TwitterProject
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
