﻿using System;

class Program
{
    static void Main()
    {
        var input1 = Console.ReadLine().Split();
        var name = input1[0]+" "+input1[1];
        var address = input1[2];
        var tuple1 = new Tuple<string, string>(name, address);
        Console.WriteLine(tuple1);

        var input2 = Console.ReadLine().Split();
        var element21 = input2[0];
        int element22 =int.Parse(input2[1]);
        var tuple2 = new Tuple<string, int>(element21, element22);
        Console.WriteLine(tuple2);

        var input3 = Console.ReadLine().Split();
        var element31 = int.Parse(input3[0]);
        var element32 = double.Parse(input3[1]);
        var tuple3 = new Tuple<int, double>(element31, element32);
        Console.WriteLine(tuple3);
    }
}

