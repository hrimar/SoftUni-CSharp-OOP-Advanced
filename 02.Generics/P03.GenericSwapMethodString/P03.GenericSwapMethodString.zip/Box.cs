﻿using System;
using System.Collections.Generic;
using System.Text;

public class Box<T>
{
    private T value;

    public Box(T value)
    {
        this.value = value;
    }

    //public void Swap(int index1, int index2)
    //{
        
    //}

    public override string ToString()
    {
        return $"{this.value.GetType().FullName}: {this.value}";
    }
}

