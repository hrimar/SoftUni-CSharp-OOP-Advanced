﻿namespace P01_HarvestingFields
{
    using System;
    using System.Linq;
    using System.Reflection;

    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            //var type = typeof(P01_HarvestingFields.HarvestingFields); // or
            Type type = Type.GetType("P01_HarvestingFields.HarvestingFields");

            FieldInfo[] allFields = type.GetFields(BindingFlags.Instance
                | BindingFlags.Public | BindingFlags.NonPublic); //  | BindingFlags.Static

            string input;
            while ((input = Console.ReadLine()) != "HARVEST")
            {
               
                if (input == "public")
                {
                    var publicOnly = allFields.Where(f => f.IsPublic).ToArray();
                    Print(publicOnly);
                }
                else if (input == "protected")
                {
                    var privateOnly = allFields.Where(f => f.IsFamily).ToArray();
                    Print(privateOnly);
                }
                else if (input == "private")
                {
                    var privateOnly = allFields.Where(f => f.IsPrivate).ToArray();
                    Print(privateOnly);
                }
                else if (input == "all")
                {
                    Print(allFields);
                }
            }
        }

        private static void Print(FieldInfo[] fields)
        {
            foreach (var field in fields)
            {
                var modifier = field.Attributes.ToString().ToLower();
                if (modifier == "family")
                {
                    modifier = "protected";
                }

                Console.WriteLine($"{modifier} {field.FieldType.Name} {field.Name}");
            }
        }
    }
}
