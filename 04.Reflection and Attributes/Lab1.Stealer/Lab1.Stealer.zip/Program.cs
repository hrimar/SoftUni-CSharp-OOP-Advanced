﻿using System;


class Program
{
    static void Main()
    {
        Spy spy = new Spy();
        string result = spy.StealFieldInfo("System.Text.StringBuilder", "MaxChunkSize", "ThreadIDField");
        Console.WriteLine(result);
    }
}

