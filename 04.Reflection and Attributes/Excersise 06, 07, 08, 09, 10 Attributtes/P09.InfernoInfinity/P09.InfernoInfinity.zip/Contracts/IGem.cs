﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IGem
{
    int Agility { get; }

    ClarityLevel Clarity { get; }

    int Strength { get; }

    int Vitality { get; }
}


