﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P09.InfernoInfinity.Contracts
{
  public  interface IExecutable
    {
        void Execute();
    }
}
