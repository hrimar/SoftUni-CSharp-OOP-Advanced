﻿using System;
using System.Collections.Generic;
using System.Text;

[Custom("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
public class Weapon
{

}

