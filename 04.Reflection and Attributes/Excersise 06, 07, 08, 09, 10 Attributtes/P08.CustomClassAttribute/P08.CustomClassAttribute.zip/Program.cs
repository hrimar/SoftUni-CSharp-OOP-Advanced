﻿using System;
using System.Linq;
using System.Reflection;

class Program
{
    static void Main(string[] args)
    {
        var type = Type.GetType("Weapon");
     //   var fields = type.GetFields

        string input;
        while ((input=Console.ReadLine()) !="END")
        {

            var targetAttribute = type.GetCustomAttribute<CustomAttribute>();

            switch (input)
            {
                case "Author":
                    Console.WriteLine($"Author: "+ targetAttribute.Author);
                    break;
                case "Revision":
                    Console.WriteLine($"Revision: " + targetAttribute.Revision);
                    break;
                case "Description":
                    Console.WriteLine($"Class description: " + targetAttribute.Description);
                    break;
                case "Reviewers":
                    //Console.WriteLine("Attributes.");
                    Console.WriteLine($"Reviewers: " + string.Join(", ", targetAttribute.Reviewers));
                    break;
                default:
                    break;
            }

        }
    }
}

