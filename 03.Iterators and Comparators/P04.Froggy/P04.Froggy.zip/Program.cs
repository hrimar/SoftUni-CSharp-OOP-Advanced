﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {

        var input = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
        var lake = new Lake(input);

        Console.WriteLine(string.Join(", ", lake));
    }
}

