﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.EventImplementation.Contracts
{
   public interface INamable
    {
        string Name { get; }

      
    }
}
