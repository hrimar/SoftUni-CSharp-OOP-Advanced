﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02.KingsGambit.Contracts
{
   public interface IKing : IBoss, IAttackable, INamable
    {
    }
}
