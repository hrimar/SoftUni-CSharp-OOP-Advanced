﻿using P03_DependencyInversion.Contracts;

namespace P03_DependencyInversion.Strategies
{
	public class SubtractionStrategy : ICalculationStrategy
    {
        public int Calculate(int firstOperand, int secondOperand)
        {
            return firstOperand - secondOperand;
        }
    }
}
